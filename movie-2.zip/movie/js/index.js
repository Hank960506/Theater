var m=0
$(".m1").click(function(){
   
   m++;
   
   $(".m1").css("width","90%");
   $(".m1 img").css("left","0%");
   $(".m2").css("width","0%")
   $(".m3").css("width","0%")
   $(".m1 .booking").css("opacity","1")
                    
   if(m>1){
   $(".m1").css("width","30%");
   $(".m2").css("width","30%")
   $(".m3").css("width","30%")
   $(".booking").css("opacity","0")
   m=0; }}
   )

$(".m2").click(function(){
   
   m++;
   
   $(".m2").css("width","90%");
   $(".m2 img").css("left","0%");
   $(".m1").css("width","0%")
   $(".m3").css("width","0%")
   $(".m2 .booking").css("opacity","1")
   if(m>1){
   $(".m1").css("width","30%");
   $(".m2").css("width","30%")
   $(".m3").css("width","30%") 
   $(".booking").css("opacity","0")
   m=0; }}
   )
$(".m3").click(function(){
   
   m++;
  
   $(".m3").css("width","90%");
   $(".m3 img").css("left","0%");
   $(".m1").css("width","0%")
   $(".m2").css("width","0%")
   $(".m3 .booking").css("opacity","1")
   if(m>1){
   $(".m1").css("width","30%");
   $(".m2").css("width","30%")
   $(".m3").css("width","30%")
   $(".booking").css("opacity","0")
   m=0; }}
   )




var price = 150; //票價
$(document).ready(function() {
  var $cart = $("#selected-seats"), //座位區
    $counter = $("#counter"), //票數
    $total = $("#total"); //總計金額

  var sc = $("#seatmap").seatCharts({
    map: [
      //座位圖
      "aaaaaaaaaa",
      "aaaaaaaaaa",
      "__________",
      "__aaaaaa__",
      "aaaaaaaaaa",
      "aaaaaaaaaa",
      "aaaaaaaaaa",
      "aaaaaaaaaa",
      "aaaaaaaaaa",
      "aa__aa__aa"
    ],
    legend: {
      //定義
      node: $("#legend"),
      items: [["a", "available", "可选座"], ["a", "unavailable", "已售出"]]
    },
    click: function() {
      
      if (this.status() == "available") {
        //選位子
        $(
          "<li>" +
            (this.settings.row + 1) +
            "排" +
            this.settings.label +
            "座</li>"
        )
          .attr("id", "cart-item-" + this.settings.id)
          .data("seatId", this.settings.id)
          .appendTo($cart);

        $counter.text(sc.find("selected").length + 1);
        $total.text(recalculateTotal(sc) + price);

        return "selected";
      } else if (this.status() == "selected") {
        //已選中
        //更新數量
        $counter.text(sc.find("selected").length - 1);
        //更新總計
        $total.text(recalculateTotal(sc) - price);

        //删除已預定的位子
        $("#cart-item-" + this.settings.id).remove();
        //可選位
        return "available";
      } else if (this.status() == "unavailable") {
        //已售出
        return "unavailable";
      } else {
        return this.style();
      }
    }
  });
  //已售出的座位
  sc
    .get([
      "1_2",
      "4_4",
      "4_5",
      "6_6",
      "6_7",
      "8_5",
      "8_6",
      "8_7",
      "8_8",
      "10_1",
      "10_2"
    ])
    .status("unavailable");
});
//計算總金額
function recalculateTotal(sc) {
  var total = 0;
  sc.find("selected").each(function() {
    total += price;
  });

  return total;
}